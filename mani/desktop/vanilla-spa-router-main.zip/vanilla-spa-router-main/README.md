# vanilla-spa-router

A vanilla js solution to routing for a single-page application

## Try it out

Clone this repo to your machine and start it up in a live server. VSCode has a good extension for this. Then visit the site at localhost on the port your server is running on.

I also created a codesandbox you can try out [here](https://codesandbox.io/s/vanilla-spa-router-59tyx?file=/js/router.js). You'll have to refresh the preview browser on first load, but it will work just the same otherwise.
